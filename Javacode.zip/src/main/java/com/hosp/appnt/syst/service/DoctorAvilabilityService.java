package com.hosp.appnt.syst.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hosp.appnt.syst.entity.DoctorAvilability;
import com.hosp.appnt.syst.repository.DoctorAvilabilityRepo;

@Service
public class DoctorAvilabilityService {

	@Autowired
	DoctorAvilabilityRepo doctorAvilabilityRepo ;

	public List<DoctorAvilability> getDoctoctorsDetails() {
		return doctorAvilabilityRepo.findAll();
	}
}
