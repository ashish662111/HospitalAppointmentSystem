package com.hosp.appnt.syst.pdfreader;

import java.io.FileOutputStream;

import com.hosp.appnt.syst.entity.PatientDetails;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
 
public class JavaPdfHelloWorld
{

	public static void createPdfFile(PatientDetails patientDetails,String filePath) {

		Document document = new Document();
		try {
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath+"Patient.pdf"));
			document.open();

			PdfPTable table = new PdfPTable(6); // 6 columns.
			table.setWidthPercentage(100); // Width 100%

			/*
			 * table.setSpacingBefore(10f); //Space before table table.setSpacingAfter(10f);
			 * //Space after table
			 */
			// Set Column widths
			float[] columnWidths = { 1f, 1f, 1f, 1f, 1f, 1f };
			table.setWidths(columnWidths);

			PdfPCell cell1 = new PdfPCell(new Paragraph("Patient Name"));
			cell1.setBorderColor(BaseColor.BLUE);
			cell1.setPaddingLeft(5);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cell2 = new PdfPCell(new Paragraph("Patient Age"));
			cell2.setBorderColor(BaseColor.BLUE);
			cell2.setPaddingLeft(5);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setVerticalAlignment(Element.ALIGN_BOTTOM);

			PdfPCell cell3 = new PdfPCell(new Paragraph("Patient Date of Birth"));
			cell3.setBorderColor(BaseColor.BLUE);
			cell3.setPaddingLeft(5);
			cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cell4 = new PdfPCell(new Paragraph("Email Id"));
			cell4.setBorderColor(BaseColor.BLUE);
			cell4.setPaddingLeft(5);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cell5 = new PdfPCell(new Paragraph("Mobile Number"));
			cell5.setBorderColor(BaseColor.BLUE);
			cell5.setPaddingLeft(5);
			cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cell6 = new PdfPCell(new Paragraph("Requested Date"));
			cell6.setBorderColor(BaseColor.BLUE);
			cell6.setPaddingLeft(5);
			cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

			// To avoid having the cell border and the content overlap, if you are having
			// thick cell borders
			// cell1.setUserBorderPadding(true);
			// cell2.setUserBorderPadding(true);
			// cell3.setUserBorderPadding(true);

			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);

			document.add(table);

			PdfPTable table1 = new PdfPTable(6); // 6 columns.
			table1.setWidthPercentage(100); // Width 100%
			/*
			 * table1.setSpacingBefore(10f); //Space before table
			 * table1.setSpacingAfter(10f);
			 */ // Space after table

			// Set Column widths
			float[] columnWidths1 = { 1f, 1f, 1f, 1f, 1f, 1f };
			table.setWidths(columnWidths1);

			PdfPCell cellv1 = new PdfPCell(new Paragraph(patientDetails.getName()));
			cellv1.setBorderColor(BaseColor.BLUE);
			cellv1.setPaddingLeft(5);
			cellv1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv1.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cellv2 = new PdfPCell(new Paragraph(patientDetails.getAge()+""));
			cellv1.setBorderColor(BaseColor.BLUE);
			cellv1.setPaddingLeft(5);
			cellv1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv1.setVerticalAlignment(Element.ALIGN_BOTTOM);

			PdfPCell cellv3 = new PdfPCell(new Paragraph(patientDetails.getDob()));
			cellv3.setBorderColor(BaseColor.BLUE);
			cellv3.setPaddingLeft(5);
			cellv3.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv3.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cellv4 = new PdfPCell(new Paragraph(patientDetails.getEmailId()));
			cellv4.setBorderColor(BaseColor.BLUE);
			cellv4.setPaddingLeft(5);
			cellv4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv4.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cellv5 = new PdfPCell(new Paragraph(patientDetails.getMobNo()+""));
			cellv5.setBorderColor(BaseColor.BLUE);
			cellv5.setPaddingLeft(5);
			cellv5.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv5.setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPCell cellv6 = new PdfPCell(new Paragraph(patientDetails.getReqDate()));
			cellv6.setBorderColor(BaseColor.BLUE);
			cellv6.setPaddingLeft(5);
			cellv6.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellv6.setVerticalAlignment(Element.ALIGN_MIDDLE);

			table1.addCell(cellv1);
			table1.addCell(cellv2);
			table1.addCell(cellv3);
			table1.addCell(cellv4);
			table1.addCell(cellv5);
			table1.addCell(cellv6);

			document.add(table1);

			document.close();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

   
}