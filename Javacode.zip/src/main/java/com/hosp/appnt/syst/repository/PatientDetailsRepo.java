package com.hosp.appnt.syst.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hosp.appnt.syst.entity.PatientDetails;

@Repository
public interface PatientDetailsRepo extends JpaRepository<PatientDetails, Number>{

}
