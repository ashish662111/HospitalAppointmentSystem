package com.hosp.appnt.syst.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hosp.appnt.syst.entity.PatientDetails;
import com.hosp.appnt.syst.repository.PatientDetailsRepo;

@Service
public class PatientDetailsService {

	@Autowired
	PatientDetailsRepo patientDetailsRepo ;
	
	public PatientDetails saveorUpdatePatientDetails(PatientDetails patientDetails) {
		return patientDetailsRepo.save(patientDetails);
	}

	public List<PatientDetails> getPatientDetails() {
		return patientDetailsRepo.findAll();
	}
}
