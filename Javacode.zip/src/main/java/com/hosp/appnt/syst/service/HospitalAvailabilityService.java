package com.hosp.appnt.syst.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hosp.appnt.syst.entity.DoctorAvilability;
import com.hosp.appnt.syst.entity.PatientDetails;
import com.hosp.appnt.syst.pdfreader.JavaPdfHelloWorld;

@Service
public class HospitalAvailabilityService {

	@Autowired
	private PatientDetailsService patientDetailsService;
	
	@Autowired
	private DoctorAvilabilityService doctorAvilabilityService;
	
	@Autowired
	private MailSenderService mailSenderService;
	
	
	public String hospitalAvailabilityServiceCheck(PatientDetails patientDetails) throws IOException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMHHmmss");  
		String filepath = patientDetails.getName()+formatter.format(new Date()) ;
		JavaPdfHelloWorld.createPdfFile(patientDetails,filepath);
		Files.move(Paths.get(filepath+"Patient.pdf"),Paths.get("C:/GaneshN/ws/stsWs/sts46/PatientForm/"+filepath+"Patient.pdf"));
		patientDetails.setFilepath("C:/GaneshN/ws/stsWs/sts46/PatientForm/"+filepath+"Patient.pdf");
		patientDetailsService.saveorUpdatePatientDetails(patientDetails);
		
		List<DoctorAvilability> list = doctorAvilabilityService.getDoctoctorsDetails();
		String dctravlblTime = null,patientavlblTime = null;
		try {
			 dctravlblTime = list.get(0).getAvailabledateandtime().split(",")[0];
			 patientavlblTime = patientDetails.getReqDate().split(",")[0];
			 Boolean drFlag = false;
				if(dctravlblTime.equalsIgnoreCase(patientavlblTime))
					drFlag = true;
					
			mailSenderService.sendMail(patientDetails,drFlag);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return null;
		
	}


	
}
