package com.hosp.appnt.syst.entity.contrlr;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hosp.appnt.syst.entity.PatientDetails;
import com.hosp.appnt.syst.service.HospitalAvailabilityService;
import com.hosp.appnt.syst.service.PatientDetailsService;

@RestController
public class PatientDetailsContoller {

	@Autowired
	private PatientDetailsService patientDetailsService;
	
	@Autowired
	private HospitalAvailabilityService hospitalAvailabilityService;

	@GetMapping("/getpatientdetails")
	public List<PatientDetails> getAllEmployees() {
		return patientDetailsService.getPatientDetails();
	}

	@PostMapping("/saveorupdatepatientdetails")
	public Model saveorUpdatePatientDetails(@ModelAttribute("patientDetails") PatientDetails patientDetails,Model model) {
		model.addAttribute("patientDetails", "Records has been added");
		patientDetailsService.saveorUpdatePatientDetails(patientDetails);
		return model;
	} 

	@GetMapping("/register")
	public Model register(@ModelAttribute("patientDetails") PatientDetails patientDetails,Model model) {
		model.addAttribute("register_form","register_form");
		return model;
	}

	@PostMapping("/register")
	public Model submitForm(@ModelAttribute("patientDetails") PatientDetails patientDetails,Model model) throws IOException {
		model.addAttribute("patientDetails", patientDetails);
		model.addAttribute("register_success","register_success");
		model.addAttribute("successMessage","Records has been inserted successfully and Mail is sent on resp mail Id..!!");
		hospitalAvailabilityService.hospitalAvailabilityServiceCheck(patientDetails);
		return model;
	}

	
}
